#define _CRT_SECURE_NO_WARNINGS
//#include <stdio.h>
////int main()
////{
////	printf("\a");
////	return 0;
////
//
//#include <string.h>
//int main()
//{
//	char arr[2] = { 's','d'};
//	printf("%d\n",strlen(arr));
//	return 0;
//}
//int main()
//{
//	int a = 3;
//	char arr[a] = ('a', 'd');
//	return 0;
//}
//max(int a)
//{
//	if (a > 0)
//		return -1;
//	else if (a == 0)
//		return 0;
//	else
//		return 1;
//}
//int main()
//{
//	int x = 0;
//	scanf("%d", &x);
//	int y = max(x);
//	printf("%d\n", y);
//	return 0;
//
// int m}
//int main()
//{
//	//int a = 1;
//	//int b = 20;
//	//int r = (a > b ? a : b);
//	printf("%d\n", sizeof(int));
//	return 0;
//}
//struct stu
//{
//	char name[20];
//	int age;
//	char sex[5];
//	char number[12];
//};
//void print(struct stu* pf)
//{
//	printf("%s %d %s %s\n", pf->name, pf->age, pf->sex, pf->number);
//}
//
//int main()
//{
//	struct stu one = { "luobaoren",20,"nan","18928671896" };
//	struct stu two = { "zhaositinng",21,"Ů","18928671666" };
//	print(&one);
//	print(&two);
//	return 0;
//}
//int main()
//{
//	int ss=0;
//	printf("�ú�ѧϰ���߰���(0/1)\n");
//	scanf("%d", &ss);
//	if (ss == 1)
//	{
//		printf("��office\n");
//	}
//	else;
//	{
//		printf("����\n");
//	}
//	return 0;
//}
#include <stdio.h>
//int main()
//{
//	int a = 1;
//	int b = 2;
//	if (a == 1)
//	{
//		if (b == 1)
//			printf("666\n");
//		else
//			printf("aaaa\n");
//	}
//	else
//	{
//		printf("hehe\n");
//	}
//	return 0;
//}
//int main()
//{
//	int a = 0;
//	while (a <= 100)
//	{
//		if (a % 2 == 1)
//		{
//			printf(" %d ",a);
//			a++;
//		}
//		else
//			a++;
//	}
//	return 0;

//int main()
//{
//	int arr[4] = { 0 };
//	int i = 0;
//	int n = 0;
//	while (i < 4) {
//		scanf("%d", &arr[i]);
//		i++;
//	}
//	int max = 0;
//	max = arr[0];
//	for (n = 1; n < 4; n++) {
//		if (max < arr[n]) {
//			max = arr[n];
//		}
//	}
//	printf("%d\n", max);
//	return 0;
//}
//int main() {
//	int i = 1;
//	int n = 0; 
//	int ret = 1;
//	int sum = 0;
//	for (i = 1; i <= 10; i++) {
//		ret = ret * i;
//		sum = sum + ret;
//	}
//	printf("%d\n", sum);
//	return 0; 
//}
//int main() {
//	int arr[] = { 1,2,3,4,5,6,7,8,9,10 };
//	int i = 0;
//	scanf("%d", &i);
//	int sz = sizeof(arr) / sizeof(arr[0]);
//	int left = 0;
//	int right = sz - 1;
//	while (left <= right) {
//		int mid = (left + right) / 2;
//		if(arr[mid]<i)
//			left++;
//		else if (arr[mid] > i)
//			right--;
//		else 
//		{
//			printf("%d\n", arr[mid]-1);
//			break;
//
//		}
//	}
//	if (left > right) {
//		printf("�Ҳ���");
//	}
//	return 0;
//}
#include <Windows.h>
int main() {
	char arr1[] = { "��Ҫѽ����Ҫѽ������������ȥ��ŶŶ" };
	char arr2[] = { "##################################" };
	int left = 0;
	int right = strlen(arr1)-1;
	int i = 0;
	for (int i = 0; i <= strlen(arr1) / 2; i++) {
		if (i % 2 != 1) {
			arr2[left] = arr1[left];
			arr2[right] = arr1[right];
			left++;
			right--;
			continue;
		}
		arr2[left] = arr1[left];
		arr2[right] = arr1[right];
		system("cls");
		printf("%s\n", arr2);
		Sleep (1000);
		left++;
		right--;
	}
	return 0;

}